<?php
session_start();
include '../../config.php';

if (!isset($_SESSION['user'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

$user_id = $_SESSION['user_id']; // Assuming you store user ID in session
$recipe_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($recipe_id == 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid recipe ID']);
    exit();
}

$db = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$query = "INSERT INTO Favourites (UsersID, RecipeID) VALUES (?, ?)";
$stmt = $db->prepare($query);
$stmt->bind_param("ii", $user_id, $recipe_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to add favorite']);
}

$stmt->close();
$db->close();
?>