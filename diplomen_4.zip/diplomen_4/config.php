<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'recipe_db');
define('BASE_URL', 'http://localhost/diplomen_4/');
// Other configuration settings
// define('SITE_NAME', 'My Website');
// define('BASE_URL', 'http://localhost/diplomen_4/');

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
