<?php

session_start();
include '../../config.php';

header('Content-Type: application/json');

// Database connection
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASSWORD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $recipeId = isset($_GET['id']) ? intval($_GET['id']) : null;

    if ($recipeId) {
        // Fetch the recipe from the database
        $stmt = $pdo->prepare("SELECT ID, Name, Time, Instructions FROM RECIPE WHERE ID = :id");
        $stmt->bindParam(':id', $recipeId, PDO::PARAM_INT);
        $stmt->execute();

        $recipe = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($recipe) {
            // Fetch ingredients for the recipe
            $stmt = $pdo->prepare("SELECT i.Name, i.Measurement FROM Ingredients i JOIN RECIPE_INGREDIENTS ri ON i.ID = ri.IngredientID WHERE ri.RecipeID = :id");
            $stmt->bindParam(':id', $recipeId, PDO::PARAM_INT);
            $stmt->execute();
            $ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Add ingredients to the recipe data
            $recipe['ingredients'] = $ingredients;

            // Send the recipe data as JSON
            echo json_encode($recipe);
        } else {
            // Recipe not found
            http_response_code(404);
            echo json_encode(['error' => 'Recipe not found', 'recipeId' => $recipeId]);
        }
    } else {
        // Recipe ID not provided
        http_response_code(400);
        echo json_encode(['error' => 'Recipe ID not provided']);
    }
} catch (PDOException $e) {
    // Handle the database connection error
    http_response_code(500);
    echo json_encode(['error' => 'Database connection error', 'details' => $e->getMessage()]);
}

error_log("Recipe ID received: " . $_GET['id']);
?>
