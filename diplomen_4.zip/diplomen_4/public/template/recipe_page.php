<?php
session_start();
require_once '../../config.php';

// Get the recipe ID from the URL
$recipeID = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Validate recipe ID
if ($recipeID === 0) {
    die("Invalid recipe ID. Please provide a valid recipe ID in the URL.");
}

try {
    // Use PDO for database connection
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASSWORD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch recipe data from the database
    $stmt = $pdo->prepare("SELECT * FROM RECIPE WHERE ID = ?");
    $stmt->execute([$recipeID]);
    $recipe = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$recipe) {
        throw new Exception("Recipe not found!");
    }

    // Fetch ingredients for the selected recipe
    $stmt = $pdo->prepare("SELECT i.Name, i.Measurement
                           FROM Ingredients i
                           JOIN RECIPE_INGREDIENTS ri ON i.ID = ri.IngredientID
                           WHERE ri.RecipeID = ?");
    $stmt->execute([$recipeID]);
    $ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    // Log the error and display a user-friendly message
    error_log("Database Error: " . $e->getMessage());
    die("An error occurred while fetching the recipe. Please try again later.");
} catch (Exception $e) {
    die($e->getMessage());
}

// Recipe image URL (consider moving this to the database)
$recipe_images = [
    'Pasta Carbonara' => '/diplomen_4/public/photos/5e24db6215db855d7e036741cb5c115d.jpg',
    'Margarita Pizza' => '/diplomen_4/public/photos/margarita_pizza.jpg',
    'Caesar Salad' => '/diplomen_4/public/photos/caesar_salad.jpg',
];

$image_url = isset($recipe_images[$recipe['Name']]) ? $recipe_images[$recipe['Name']] : '/diplomen_4/public/public/photos/5e24db6215db855d7e036741cb5c115d.jpg';
?>

<!DOCTYPE html>
<html lang="en">  
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($recipe['Name']) ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>public/template/recipe_page.css">
    <script src="<?= BASE_URL ?>public/template/recipe_page.js" defer></script>
</head>
<body>
    <div class="page-container">
        <nav class="header-container">
      <div class="logo">
        <span class="logo-text">Logo</span>
      </div>
      <ul class="nav-links" id="navLinks">
        <?php if (isset($_SESSION['user'])) { ?>
          <li><a href="/diplomen_4/public/home-page/home_page_logged.php" class="header-text home">Home</a></li>
          <li><a href="/diplomen_4/public/profile-page/profile.php" class="header-text profile">Profile</a></li>
          <li><a href="/diplomen_4/public/recipes-pages/recipes_logged.php" class="header-text recipes">Recipes</a></li>
          <li><a href="/diplomen_4/public/popular-page/popular_logged.php" class="header-text popular">Popular</a></li>
        <?php } else { ?>
          <li><a href="/diplomen_4/public/home-page/home_page.php" class="header-text home">Home</a></li>
          <li><a href="/diplomen_4/public/log-in/log_in.php" class="header-text log in">Log in</a></li>
          <li><a href="/diplomen_4/public/recipes-pages/recipes.php" class="header-text recipes">Recipes</a></li>
        <?php } ?>
        <li>
          <a href="#" class="header-text search-icon" id="searchIcon" onclick="toggleSearch()">
            <img src="/diplomen_4/public/icons/magnifying-glass.png" alt="Search" style="width: 20px; height: 20px;">
          </a>
        </li>
      </ul>
      <div class="search-bar" id="searchBar">
        <input type="text" id="searchInput" placeholder="Search recipes...">
        <img src="/diplomen_4/public/icons/magnifying-glass.png" alt="Search" class="search-icon" onclick="searchRecipes()">
      </div>
    </nav>

    <div class="recipe-container">
            <h1><?= htmlspecialchars($recipe['Name']) ?></h1>
            <img src="<?= htmlspecialchars($image_url) ?>" alt="<?= htmlspecialchars($recipe['Name']) ?>" class="recipe-image">
            <button class="favorite-button" onclick="toggleFavorite(<?= $recipe['ID'] ?? 'null' ?>)">
               <img src="<?= BASE_URL ?>public/icons/favorite.png" alt="Favorite"> 
            </button>

            <div class="recipe-details">
                <p><strong>Preparation Time:</strong> <?= htmlspecialchars($recipe['Time']) ?></p>
                <p><strong>Instructions:</strong> <?= nl2br(htmlspecialchars($recipe['Instructions'])) ?></p>
            </div>
            <h2>Ingredients</h2>
            <ul>
                <?php foreach ($ingredients as $ingredient): ?>
                    <li><?= htmlspecialchars($ingredient['Name']) ?> - <?= htmlspecialchars($ingredient['Measurement']) ?></li>
                <?php endforeach; ?>
                <?php if (empty($ingredients)): ?>
                    <p>No ingredients found.</p>
                <?php endif; ?>
            </ul>
        </div>

        <footer class="footer">
            <span class="footer-text">All rights reserved ®</span>
        </footer>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const recipeId = new URLSearchParams(window.location.search).get('id');
            if (recipeId) {
                fetchRecipeById(recipeId);
            }
        });

        async function fetchRecipeById(id) {
            try {
                const response = await fetch(`/diplomen_4/public/template/get_recipe.php?id=${id}`);
                if (!response.ok) {
                    throw new Error('Recipe not found');
                }
                const recipe = await response.json();
                displayRecipe(recipe); // Display recipe only if fetch is successful
            } catch (error) {
                console.error('Error fetching recipe:', error);
                // Display an error message in the `.recipe-container`
                const recipeContainer = document.querySelector('.recipe-container');
                if (recipeContainer) {
                    recipeContainer.innerHTML = '<p>Recipe not found. Please try again later.</p>';
                }
            }
        }

        function displayRecipe(recipe) {
            const recipeContainer = document.querySelector('.recipe-container');
            recipeContainer.innerHTML = `
                <h1>${recipe.Name}</h1>
                <img src="${recipe.image}" alt="${recipe.Name}" class="recipe-image">
                <button class="favorite-button" onclick="toggleFavorite(${recipe.ID})">
                    <img src="/diplomen_4/public/icons/favorite.png" alt="Favorite" id="favoriteIcon">
                </button>
                <div class="recipe-details">
                    <p><strong>Preparation Time:</strong> ${recipe.Time}</p>
                    <p><strong>Instructions:</strong> ${recipe.Instructions}</p>
                </div>
                <h2>Ingredients</h2>
                <ul>
                    ${recipe.ingredients.map(ingredient => `<li>${ingredient.name} - ${ingredient.measurement}</li>`).join('')}
                </ul>
            `;
        }

        function toggleFavorite(recipeId) {
            const favoriteIcon = document.getElementById('favoriteIcon');
            const isFavorite = favoriteIcon.src.includes('favourite.png');

            if (isFavorite) {
                favoriteIcon.src = '/diplomen_4/public/icons/favourite__filled.png';
                removeFavorite(recipeId);
            } else {
                favoriteIcon.src = '/diplomen_4/public/icons/favourite.png';
                addFavorite(recipeId);
            }
        }

        function addFavorite(recipeId) {
            fetch(`/diplomen_4/public/template/add_favorite.php?id=${recipeId}`, {
                method: 'POST'
            }).then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('Recipe added to favorites');
                } else {
                    console.error('Failed to add recipe to favorites');
                }
            });
        }

        function removeFavorite(recipeId) {
            fetch(`/diplomen_4/public/template/remove_favorite.php?id=${recipeId}`, {
                method: 'POST'
            }).then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('Recipe removed from favorites');
                } else {
                    console.error('Failed to remove recipe from favorites');
                }
            });
        }
    </script>
</body>
</html>
